
#ifndef USBTMC_APP_H
#define USBTMC_APP_H

void usbtmc_app_task_iter(void);

#endif
