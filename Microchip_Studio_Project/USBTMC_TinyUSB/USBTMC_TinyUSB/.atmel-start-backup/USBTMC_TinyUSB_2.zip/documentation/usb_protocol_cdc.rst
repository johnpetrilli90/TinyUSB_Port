================
USB CDC Protocol
================

USB CDC Protocol is a part of the USB Device Stack library. It provides basic
macro definitions and data structures which are compliant with CDC(Communications
Device Class) Specification version 1.2.


Applications
------------

N/A

Dependencies
------------

N/A


Limitations
-----------

N/A
